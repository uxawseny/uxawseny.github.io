package com.xdclass.search.dao;

import com.xdclass.search.model.YearBookInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface YearBookInfoDao {

    @Select("select * from t_wsjd_yearbooks_info")
    public List<YearBookInfo> selectAll();
}
