package com.example.demo.example.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.demo.example.entity.SecretFlagEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface ConfigMapper extends BaseMapper<SecretFlagEntity> {

    @Select("select secret_switch from secret_flag where id=1 limit 1")
    String getSecretFlag();

}
