package com.xdclass.search.controller;

import com.xdclass.search.model.YearBookInfo;
import com.xdclass.search.service.YearBookInfoService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/yearbook")
public class YearBookInfoController {

    @Autowired
    private YearBookInfoService yearBookInfoService;

    @RequestMapping("/importAll")
    public String importAll(){
        try {
            yearBookInfoService.importAll();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "success";
    }

    @RequestMapping("/searchMatch")
    public List<YearBookInfo> searchMatch(@RequestParam(value = "keyWords", required = false) String keyWords) {
        try {
            return yearBookInfoService.searchMatch("infoContent",keyWords);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @RequestMapping("/searchTerm")
    public List<YearBookInfo> searchTerm(@RequestParam(value = "country", required = false) String country,
                                      @RequestParam(value = "teamName", required = false) String teamName) {
        try {
            if(StringUtils.isNoneBlank(country))
                return yearBookInfoService.searchTerm("country",country);

            else if(StringUtils.isNoneBlank(teamName))
                return yearBookInfoService.searchTerm("teamName",teamName);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    @RequestMapping("/searchMatchPrefix")
    public List<YearBookInfo> searchMatchPrefix(@RequestParam(value = "displayNameEn", required = false) String displayNameEn) {
        try {
            return yearBookInfoService.searchMatchPrefix("displayNameEn",displayNameEn);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
