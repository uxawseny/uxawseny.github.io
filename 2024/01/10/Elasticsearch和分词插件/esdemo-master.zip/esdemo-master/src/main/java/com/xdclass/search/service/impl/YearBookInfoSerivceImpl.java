package com.xdclass.search.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.xdclass.search.dao.YearBookInfoDao;
import com.xdclass.search.model.YearBookInfo;
import com.xdclass.search.service.YearBookInfoService;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.cglib.beans.BeanMap;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

@Service
public class YearBookInfoSerivceImpl implements YearBookInfoService {

    @Resource
    private RestHighLevelClient client;

    @Resource
    private YearBookInfoDao yearBookInfoDao;

    private static final String DB_INDEX = "t_wsjd_yearbooks_info";

    private static final int START_OFFSET = 0;

    private static final int MAX_COUNT = 100;

    @Override
    public boolean importAll() throws IOException {
        List<YearBookInfo> list = yearBookInfoDao.selectAll();
        //todo 指定分词器
        for (YearBookInfo info : list) {
            addPlayer(info, String.valueOf(info.getInfoId()));
        }
        return true;
    }

    @Override
    public boolean addPlayer(YearBookInfo info, String id) throws IOException {
        IndexRequest request = new IndexRequest(DB_INDEX).id(id).source(beanToMap(info));
        IndexResponse response = client.index(request, RequestOptions.DEFAULT);
        System.out.println(JSONObject.toJSON(response));
        return false;
    }

    @Override
    public List<YearBookInfo> searchMatch(String key, String value) throws IOException {
        SearchRequest searchRequest = new SearchRequest(DB_INDEX);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchQuery(key, value));
        searchSourceBuilder.from(START_OFFSET);
        searchSourceBuilder.size(MAX_COUNT);
        //过滤匹配度 todo 设置默认值，用户可修改匹配度
        searchSourceBuilder.minScore(10f);
        searchRequest.source(searchSourceBuilder);
        SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
        System.out.println(JSONObject.toJSON(response));

        SearchHit[] hits = response.getHits().getHits();
        List<YearBookInfo> List = new LinkedList<>();
        for (SearchHit hit : hits) {
            YearBookInfo info = JSONObject.parseObject(hit.getSourceAsString(), YearBookInfo.class);
            //相关度
            info.setScore(hit.getScore()+"");
            List.add(info);
        }

        return List;
    }

    @Override
    public List<YearBookInfo> searchTerm(String key, String value) throws IOException {
        SearchRequest searchRequest = new SearchRequest(DB_INDEX);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.termQuery(key, value));
        searchSourceBuilder.from(START_OFFSET);
        searchSourceBuilder.size(MAX_COUNT);
        searchSourceBuilder.minScore(0.2f);
        searchRequest.source(searchSourceBuilder);
        SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
        System.out.println(JSONObject.toJSON(response));

        SearchHit[] hits = response.getHits().getHits();
        List<YearBookInfo> playerList = new LinkedList<>();
        for (SearchHit hit : hits) {
            YearBookInfo player = JSONObject.parseObject(hit.getSourceAsString(), YearBookInfo.class);
            playerList.add(player);
        }

        return playerList;
    }


    @Override
    public List<YearBookInfo> searchMatchPrefix(String key, String value) throws IOException {
        SearchRequest searchRequest = new SearchRequest(DB_INDEX);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.prefixQuery(key, value));
        searchSourceBuilder.from(START_OFFSET);
        searchSourceBuilder.size(MAX_COUNT);
        searchSourceBuilder.minScore(0.2f);
        searchRequest.source(searchSourceBuilder);
        SearchResponse response = client.search(searchRequest, RequestOptions.DEFAULT);
        System.out.println(JSONObject.toJSON(response));

        SearchHit[] hits = response.getHits().getHits();
        List<YearBookInfo> playerList = new LinkedList<>();
        for (SearchHit hit : hits) {
            YearBookInfo player = JSONObject.parseObject(hit.getSourceAsString(), YearBookInfo.class);
            playerList.add(player);
        }

        return playerList;
    }


    public static <T> Map<String, Object> beanToMap(T bean) {
        Map<String, Object> map = new HashMap<>();
        if (bean != null) {
            BeanMap beanMap = BeanMap.create(bean);
            for (Object key : beanMap.keySet()) {
                if (beanMap.get(key) != null)
                    map.put(key + "", beanMap.get(key));
            }
        }
        return map;
    }
}
