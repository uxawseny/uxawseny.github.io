package com.example.demo.example;

import com.example.demo.example.entity.UserEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/secret")
public class TestController {

    @GetMapping("/test")
    public UserEntity test(){
        UserEntity user = new UserEntity();
        user.setRealName("张三（学生）")
                .setPhoneNumber("18000000000")
                .setAddress("蓝星地球村太平洋100号")
                .setIdCard("610000000000000000");
//        System.out.println(user);
        return user;
    }

}