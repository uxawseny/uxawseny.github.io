package com.xdclass.search.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("t_wsjd_yearbooks_info")
public class YearBookInfo {
    //id
    private String infoId;
    //年鉴id
    private String ybId;
    //内容
    private String infoContent;
    //国家
    private String nation;
    //团长
    private String delegationHead;
    //来访团类别（如政府（一级、二级、三级）、使领馆、友城、国际组织、世界500强等）
    private String delegationType;
    //开始的日期
    private String startDate;
    //结束日期
    private String endDate;
    //浙方领导
    private String leader;
    //目录id
    private String ycId;
    //子目录名
    private String ycName;
    //年鉴页码数
    private String pages;
    //默认排序号
    private String sort;
    //标题
    private String infoTitle;
    //删除标记（逻辑删除）
    private String isDelete;
    //创建人Id
    private String creatorId;
    //创建人姓名
    private String creatorName;
    //创建日期
    private String createDate;
    //修改人Id
    private String lastEditorId;
    //修改人姓名
    private String lastEditorName;
    //修改日期
    private String lastEditDate;
    //对方城市
    private String oppositeCity;
    //我方城市
    private String ourCity;
    //我方单位（省级单位、高校等）
    private String ourUnit;
    //数据是否锁定
    private String isLock;
    //pdf文件页
    private String pdfPages;
    //国家id
    private String nationId;
    //城市id
    private String oppositeCityId;
    //我方城市编码
    private String ourCityCode;

    //相关度
    @TableField(exist = false)
    private String score;
}
