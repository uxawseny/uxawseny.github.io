package com.xdclass.search.service;

import com.xdclass.search.model.YearBookInfo;

import java.io.IOException;
import java.util.List;

public interface YearBookInfoService {

    boolean addPlayer(YearBookInfo player, String id) throws IOException;

    boolean importAll() throws IOException;

    List<YearBookInfo> searchMatch(String key, String value) throws IOException;

    List<YearBookInfo> searchTerm(String key,String value) throws IOException;

    List<YearBookInfo> searchMatchPrefix(String key,String value) throws IOException;

}
