package com.example.demo.example.annotation;


import com.example.demo.example.SecretJsonConfig.SecretJsonSerializer;
import com.example.demo.example.SecretJsonConfig.SecretStrategy;
import com.fasterxml.jackson.annotation.JacksonAnnotationsInside;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**标注在字段上*/
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
/**一般用于将其他的注解一起打包成"组合"注解*/
@JacksonAnnotationsInside
/**对标注注解的字段采用哪种序列化器进行序列化*/
@JsonSerialize(using = SecretJsonSerializer.class)
public @interface SecretColumn {

    /**脱敏策略*/
    SecretStrategy strategy();


}