package com.example.demo.example.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.example.demo.example.SecretJsonConfig.SecretStrategy;
import com.example.demo.example.annotation.SecretColumn;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@TableName("secret_flag")
public class SecretFlagEntity {

    private static final long serialVersionUID = 1L;

    @TableId("id")
    private String id;

    @TableField("secret_switch")
    private String secretSwitch;
}
